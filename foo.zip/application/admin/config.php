<?php
	return [
		'template' => [
			'view_path' => APP_PATH . '../template/admin/',
		]
	];
	